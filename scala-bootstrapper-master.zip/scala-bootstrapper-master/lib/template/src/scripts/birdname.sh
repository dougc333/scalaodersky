#!/bin/sh
sh `dirname "$0"`/service.sh "$@"